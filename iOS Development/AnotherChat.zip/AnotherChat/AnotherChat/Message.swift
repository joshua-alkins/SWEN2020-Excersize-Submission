//
//  Message.swift
//  AnotherChat
//
//  Created by UWICIIT-Admin on 6/20/20.
//  Copyright © 2020 UWICIIT-Admin. All rights reserved.
//

import Foundation


class Message{
    var author = ""
    var message = ""
    var extraData = ""
    var messageType = 0
    var date : Date
    
    init(author: String, message: String, extraData: String, messageType: Int){
        self.author = author
        self.message = message
        self.extraData = extraData
        self.messageType = messageType
        self.date = Date()
    }
    
    init(author: String, message: String, extraData: String, messageType: Int, date: Date){
        self.author = author
        self.message = message
        self.extraData = extraData
        self.messageType = messageType
        self.date = date
    }
    
    func getSentDateTime() -> String{
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy/MM/dd HH:mm"
        return dateFormatter.string(from: self.date)
    }
    
    func prepSend() -> [String:Any]{
        return ["author":self.author,"messageType": self.messageType, "extraData":self.extraData, "messageText":self.message, "timeSent": self.date]
    }
}
