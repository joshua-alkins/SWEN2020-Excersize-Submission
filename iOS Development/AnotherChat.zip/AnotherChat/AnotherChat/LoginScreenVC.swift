//
//  LoginScreenVC.swift
//  AnotherChat
//
//  Created by UWICIIT-Admin on 6/20/20.
//  Copyright © 2020 UWICIIT-Admin. All rights reserved.
//

import UIKit
import AVFoundation
import UserNotifications
import FirebaseAuth
import Firebase

class LoginScreenVC: UIViewController {
    
    var player:AVAudioPlayer?
    
    @IBOutlet weak var errorLabel: UILabel!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    var user = ""
    
    let users = [["username": "user 1", "password": "pass"],["username": "user 2", "password": "pass"]]

    override func viewDidLoad() {
        super.viewDidLoad()
        errorLabel.alpha = 0
    }

    
    //Button Actions
    @IBAction func loginTapped(_ sender: Any) {
        print("verifying")
        verifyCredentials()
        
    }
    
    //Segue Data Transfer
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "loginSeg"){
            let vc  = segue.destination as! ChatScreenVC
            vc.user = self.user
            
        }
    }
    
    //Login Logic
    func verifyCredentials(){
        let email = emailTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        let password = passwordTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        
        //verify fields
        
        //sign in
        Auth.auth().signIn(withEmail: email, password: password){ (result, err) in
            if err != nil{
                self.errorLabel.text = err!.localizedDescription
            }else{
                let db = Firestore.firestore()
                db.collection("users").whereField("email", isEqualTo: email).getDocuments(){ (snapshot, err) in
                    if  err == nil{
                        for document in snapshot!.documents{
                            self.user = document.get("displayName") as! String
                        }
                    }else{
                        //error handle
                    }
                }
                self.playSound()
                self.createNotification()
                self.performSegue(withIdentifier: "loginSeg", sender: nil)
            }
        }
    }
    
    
    
    //Sounds
    func playSound(){
        let path = Bundle.main.path(forResource: "gong", ofType: "mp3")!
        let url = URL(fileURLWithPath: path)
        
        do{
            try AVAudioSession.sharedInstance().setMode(.default)
            try AVAudioSession.sharedInstance().setActive(true, options: .notifyOthersOnDeactivation)
            
            player = try AVAudioPlayer(contentsOf: url)
            player?.play()
        }catch{
            
        }
    }
    
    
    //Local Notifications
    func createNotification(){
        let center = UNUserNotificationCenter.current()
        center.requestAuthorization(options: [.alert, .sound]) { (granted, error) in
           //error handling
        }
        let content = UNMutableNotificationContent()
        content.title = "AnotherChat"
        content.body = "You may have new messages"
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: (3600), repeats: false)
        let uuidString = UUID().uuidString
        let request = UNNotificationRequest(identifier: uuidString, content: content, trigger: trigger)
        center.add(request){(error) in
           //error handling
        }
    }
    
    
    
}
