//
//  ForeignMessageCell.swift
//  AnotherChat
//
//  Created by UWICIIT-Admin on 6/20/20.
//  Copyright © 2020 UWICIIT-Admin. All rights reserved.
//

import UIKit

class ForeignMessageCell: UITableViewCell {

    @IBOutlet weak var authorLabel: UILabel!
    @IBOutlet weak var messageLabel: UILabel!
    
    func setMessage(message: Message){
        authorLabel.text = message.author
        messageLabel.text = message.message
    }
    

}
