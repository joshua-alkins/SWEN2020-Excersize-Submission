//
//  RegisterScreenVC.swift
//  AnotherChat
//
//  Created by UWICIIT-Admin on 6/20/20.
//  Copyright © 2020 UWICIIT-Admin. All rights reserved.
//

import UIKit
import FirebaseAuth
import Firebase

class RegisterScreenVC: UIViewController {

    @IBOutlet weak var errorLabel: UILabel!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var displayNameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var confirmPasswordTextField: UITextField!
    
    
    var user = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        errorLabel.alpha = 0
    }
    

    //Register Buttion Action
    @IBAction func registerTapped(_ sender: Any) {
        print("verifying")
        showMessage(msg: "Verifying")
        
        if verifyCredentials(){
            
        }
    }
    
    //Transfer Data with segue
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "registerToChatSeg"){
            let vc  = segue.destination as! ChatScreenVC
            vc.user = self.user
            
        }
    }
    
    //
    func verifyCredentials()-> Bool{
        var valid = false
        let error = verifyFields()
        if error != nil{
            showErrorMessage(error: error!)
        }else{
            //create user
            let cleanEmail = emailTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            let cleanPass = passwordTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            
            Auth.auth().createUser(withEmail:  cleanEmail, password:  cleanPass){(result, err) in
                if err != nil{
                    self.showErrorMessage(error: "\(err!.localizedDescription)")
                    
                    print("\(err.debugDescription)")
                }else{
                    valid = true
                    
                    let db = Firestore.firestore()
                    let cleanDisplay = self.displayNameTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
                    
                    self.user = cleanDisplay
                    
                    db.collection("users").addDocument(data: ["displayName": cleanDisplay, "uid": result!.user.uid, "email": cleanEmail], completion: {err in
                        
                        if err != nil {
                            //error handling
                        }else{
                           //login
                            self.performSegue(withIdentifier: "registerToChatSeg", sender: nil)
                        }
                    })
                }
            }
        }
        return valid
    }
    
    
    //ensures all fileds have been filled out correctly
    func verifyFields()->String?{
        //Clean data from text fields
        let cleanEmail = emailTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanDisplay = displayNameTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanPass = passwordTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanConfirm = confirmPasswordTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        
        
        //check if all fields have been filled in
        if cleanEmail == "" || cleanDisplay == "" || cleanPass == "" || cleanConfirm == ""{
            
            return "Please fill in all fields."
        }
        
        //confim passwords match
        if(cleanPass != cleanConfirm){
            return "Passwords do not match"
        }
        
        return nil
    }
    
    
    func showErrorMessage(error: String){
        errorLabel.text!=error
        errorLabel.alpha=1
        errorLabel.textColor = .red
    }
    
    func showMessage(msg: String){
        errorLabel.text!=msg
        errorLabel.alpha=1
        errorLabel.textColor = .blue
    }
}
