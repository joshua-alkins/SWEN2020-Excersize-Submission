//
//  ChatScreenVC.swift
//  AnotherChat
//
//  Created by UWICIIT-Admin on 6/20/20.
//  Copyright © 2020 UWICIIT-Admin. All rights reserved.
//

import UIKit
import UserNotifications
import Firebase

class ChatScreenVC: UIViewController {

    let db = Firestore.firestore()
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var messageTextField: UITextField!
    
    var user = ""
    var messages: [Message] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        retrieveMessages()

        tableView.delegate = self
        tableView.dataSource = self
        
    }
    
    //Firestore interactions
    func retrieveMessages(){
        let messageColRef = db.collection("Messages")
        
        messageColRef.order(by: "timeSent", descending: false).limit(to: 50).addSnapshotListener(includeMetadataChanges: true){ snapshot, error  in
            let documents = snapshot?.documents
            
            var newMessages :[Message] = []
            
            for document in documents!{
                let author = document.get("author")
                let messageText = document.get("messageText")
                let messageType = document.get("messageType")
                let extraData = document.get("extraData")
                
                let message = Message(author: author as! String, message: messageText as! String, extraData: extraData as! String, messageType: messageType as! Int)
                
                newMessages.append(message)
            }
            
            self.messages = newMessages
            
            self.tableView.reloadData()
            if self.messages.count != 0{
                let indexPath = IndexPath(row: self.messages.count - 1, section: 0)
                self.tableView.scrollToRow(at: indexPath, at: UITableView.ScrollPosition.bottom, animated: true)
            }
            
        }
    }
    
    func sendMessage(message: Message){
        db.collection("Messages").document().setData(message.prepSend())
    }
    
    func scrollToBottom(){
        let indexPath = IndexPath(row: messages.count - 1, section: 0)
        tableView.beginUpdates()
        tableView.scrollToRow(at: indexPath, at: UITableView.ScrollPosition.bottom, animated: true)
        tableView.endUpdates()
    }

    @IBAction func sendTapped(_ sender: Any) {
        //send button action
        print("send")
        //addMessage()
        
        
        let messageText = self.messageTextField.text
        
        if (messageText != nil && messageText != ""){
            self.messageTextField.text = ""
            
            let message = Message(author: self.user ,message: messageText ?? "empty message" ,extraData: "",messageType: 0)
        
            sendMessage(message: message)
        }
    }
    
}





//Table View Configuration
extension ChatScreenVC: UITableViewDataSource, UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return messages.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let message = self.messages[indexPath.row]
        
        
        if message.author == user{
            let cell = tableView.dequeueReusableCell(withIdentifier: "Local Message Cell") as! LocalMessageCell
            cell.setMessage(message: message)
            return cell
        }else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "Foreign Message Cell") as! ForeignMessageCell
            cell.setMessage(message: message)
            return cell
        }
        
    }
    
    
}
