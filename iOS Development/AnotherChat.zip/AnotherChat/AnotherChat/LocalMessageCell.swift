//
//  TableViewCell.swift
//  AnotherChat
//
//  Created by UWICIIT-Admin on 6/20/20.
//  Copyright © 2020 UWICIIT-Admin. All rights reserved.
//

import UIKit

class LocalMessageCell: UITableViewCell {

    @IBOutlet weak var messageLabel: UILabel!
    
    func setMessage(message: Message){
        messageLabel.text = message.message
        
    }
    
}
